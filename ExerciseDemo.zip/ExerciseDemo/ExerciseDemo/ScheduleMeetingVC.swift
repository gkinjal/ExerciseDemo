//
//  ScheduleMeetingVC.swift
//  ExerciseDemo
//
//  Created by kinjal.gadhia.ext@bayer.com on 04/02/22.
//

import UIKit



class ScheduleMeetingVC: UIViewController {
    
    //MARK: Properties
    static var storyboardInstance:ScheduleMeetingVC {
        return StoryBoard.main.instantiateViewController(withIdentifier: ScheduleMeetingVC.identifier) as! ScheduleMeetingVC
    }
    
    let startDtPickerView:UIDatePicker = {
        let datePick = UIDatePicker()
        let minutes30Later = TimeInterval(30.minutes)
        datePick.minimumDate = Date().addingTimeInterval(minutes30Later)
        datePick.date = Date().addingTimeInterval(minutes30Later)
        datePick.datePickerMode = .time
        datePick.addTarget(self, action: #selector(startTimeDiveChanged), for: .valueChanged)
        return datePick
    }()
    let endDtPickerView: UIDatePicker = {
        let datePick = UIDatePicker()
        let minutes30Later = TimeInterval(60.minutes)
        datePick.minimumDate = Date().addingTimeInterval(minutes30Later)
        datePick.date = Date().addingTimeInterval(minutes30Later)
        datePick.datePickerMode = .time
        datePick.addTarget(self, action: #selector(endTimeDiveChanged), for: .valueChanged)
        return datePick
    }()
    
    @IBOutlet weak var txtDate: UITextField!
    var meetingData:[Meetings]?
    
    @IBOutlet weak var txtEndTime: UITextField!{
        didSet{
            txtEndTime.inputView = endDtPickerView
            txtEndTime.delegate = self
        }
    }
    @IBOutlet weak var txtStartTime: UITextField!{
        didSet{
            txtStartTime.inputView = startDtPickerView
            txtStartTime.delegate = self
        }
    }
    @IBOutlet weak var txtDesc: UITextView!{
        didSet{
            txtDesc.placeholder = "Description"
        }
    }
    var dateFormatPrint = DateFormatter()
    override func viewDidLoad() {
        super.viewDidLoad()
        dateFormatPrint.dateFormat = "dd-MM-yyyy"
        txtDate.text = dateFormatPrint.string(from: Date())
        // Do any additional setup after loading the view.
    }
    
    @IBAction func onClickBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func onClickSubmit(_ sender: Any) {
        if isValidated(){
            var dict = [String:Any]()
            dict = ["start_time":txtStartTime.text ?? "",
                    "end_time":txtStartTime.text ?? "",
                    "description":txtDesc.text ?? ""]
            
            let meetingElement = Meetings(dictionary: dict)
            UserDefaults.standard.set(dict, forKey: "element")
            meetingData?.append(meetingElement)
            self.navigationController?.popViewController(animated: true)
            
        }
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}

//MARK: Custom function
extension ScheduleMeetingVC{
    @objc func startTimeDiveChanged(_ sender: UIDatePicker) {
        let formatter2 = DateFormatter()
        formatter2.dateFormat = DateFormatter.appDateTimeFormat
        let selectedDate = formatter2.string(from: sender.date)
        txtStartTime.text = selectedDate
    }
    
    @objc func endTimeDiveChanged(_ sender: UIDatePicker) {
        let formatter2 = DateFormatter()
        formatter2.dateFormat = DateFormatter.appDateTimeFormat
        let selectedDate = formatter2.string(from: sender.date)
        txtEndTime.text = selectedDate
    }
    
    func isValidated() -> Bool {
        var ErrorMsg = ""
        if txtDate.text == "" {
            ErrorMsg = "Please select meeting date"
        }
        else if txtStartTime.text == "" {
            ErrorMsg = "Please select meeting start date"
        }
        else if txtEndTime.text == "" {
            ErrorMsg = "Please select meeting end date"
        }
        else if let startDt = txtStartTime.text?.convertDate(dateFormate: DateFormatter.appDateTimeFormat),
                let endDt = txtEndTime.text?.convertDate(dateFormate: DateFormatter.appDateTimeFormat), endDt < startDt{
            ErrorMsg = "End date must be greter than start date"
        }
        else if txtDesc.text == "" {
            ErrorMsg = "Please enter meeting Description"
        }
        
        if ErrorMsg != "" {
            UIApplication.alert(title: "Error", message: ErrorMsg, style: .destructive)
            return false
        }
        else {
            return true
        }
    }
    
    
}

//MARK: TextField delegates
extension ScheduleMeetingVC: UITextFieldDelegate{
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if (textField == txtStartTime || textField == txtEndTime) && textField.text == "" {
            textField.setCurrentDate(date: Date().addingTimeInterval(TimeInterval((textField == txtStartTime ? 30.minutes : 60.minutes))))
        }
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == txtEndTime || textField == txtStartTime{
            return false
        }
        return true
    }
    
}
