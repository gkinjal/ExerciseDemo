//
//  Extensions.swift
//  ExerciseDemo
//
//  Created by kinjal.gadhia.ext@bayer.com on 04/02/22.
//

import UIKit



//https://finnwea.com/blog/adding-placeholders-to-uitextviews-in-swift
/// Extend UITextView and implemented UITextViewDelegate to listen for changes
extension UITextView: UITextViewDelegate {
    
    public func setPlaceHolderFontColor(font: UIFont, color: UIColor){
        if let placeholderLabel = self.viewWithTag(100) as! UILabel? {
            placeholderLabel.textColor = color
            placeholderLabel.font = font
        }
    }
    
    public func resetPlaceHolder(){
        if let placeholderLabel = self.viewWithTag(100) as! UILabel? {
            placeholderLabel.isHidden = self.text.count > 0
        }
    }
    
    /// Resize the placeholder when the UITextView bounds change
    override open var bounds: CGRect {
        didSet {
            self.resizePlaceholder()
        }
    }
    
    /// The UITextView placeholder text
    public var placeholder: String? {
        get {
            var placeholderText: String?
            if let placeholderLabel = self.viewWithTag(100) as? UILabel {
                placeholderText = placeholderLabel.text
            }
            return placeholderText
        }
        set {
            if let placeholderLabel = self.viewWithTag(100) as! UILabel? {
                placeholderLabel.text = newValue
                placeholderLabel.sizeToFit()
                placeholderLabel.isHidden = self.text.count > 0
            } else {
                self.addPlaceholder(newValue!)
            }
        }
    }
    /// When the UITextView did change, show or hide the label based on if the UITextView is empty or not
    ///
    /// - Parameter textView: The UITextView that got updated
    public func textViewDidChange(_ textView: UITextView) {
        if let placeholderLabel = self.viewWithTag(100) as? UILabel {
            placeholderLabel.isHidden = self.text.count > 0
        }
    }
    
    /// Resize the placeholder UILabel to make sure it's in the same position as the UITextView text
    private func resizePlaceholder() {
        if let placeholderLabel = self.viewWithTag(100) as! UILabel? {
            let labelX = self.textContainer.lineFragmentPadding
            let labelY = self.textContainerInset.top - 2
            let labelWidth = self.frame.width - (labelX * 2)
            let labelHeight = placeholderLabel.frame.height
            placeholderLabel.isHidden = self.text.count > 0
            placeholderLabel.frame = CGRect(x: labelX, y: labelY, width: labelWidth, height: labelHeight)
        }
    }
    
    /// Adds a placeholder UILabel to this UITextView
    private func addPlaceholder(_ placeholderText: String) {
        let placeholderLabel = UILabel()
        
        placeholderLabel.text = placeholderText
        placeholderLabel.sizeToFit()
        
        placeholderLabel.font = self.font
        placeholderLabel.textColor = UIColor.lightGray
        placeholderLabel.tag = 100
        
        placeholderLabel.isHidden = self.text.count > 0
        
        self.addSubview(placeholderLabel)
        self.resizePlaceholder()
        self.delegate = self
    }
    
}
extension Int {
    var seconds: Int {
        return self
    }
    var minutes: Int {
        return self.seconds * 60
    }
    var hours: Int {
        return self.minutes * 60
    }
    var days: Int {
        return self.hours * 24
    }
    var weeks: Int {
        return self.days * 7
    }
    var months: Int {
        return self.weeks * 4
    }
    var years: Int {
        return self.months * 12
    }
}
extension DateFormatter{
    static let appDateTimeFormat = "HH:mm" //"dd-MM-yyyy"//"MM-dd-yyyy" //"yyyy-MM-dd HH:mm" //"yyyy-MM-dd"
    static let appDateFormat = "yyyy-MM-dd"
    static let appDateDisplayFormate = "HH:mm"
}
extension String{
    func convertDate(dateFormate : String) -> Date? {
        let dateFormator = DateFormatter()
        dateFormator.dateFormat = dateFormate
        return dateFormator.date(from: self)
    }
}

extension Date{
    func convertDate(dateFormate : String) -> String? {
        let dateFormator = DateFormatter()
        dateFormator.dateFormat = dateFormate
        return dateFormator.string(from: self)
    }
}

extension UIApplication{
    
    static var rootVC: UIViewController?{
        return UIApplication.shared.keyWindow?.rootViewController
    }
    
    static func alert(title: String, message : String, style: UIAlertAction.Style = .default){
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)//, blurStyle: .light)
        let OKAction = UIAlertAction(title: "Ok", style: style, handler: nil)
        alertController.addAction(OKAction)
        UIApplication.rootVC?.present(alertController, animated: true, completion: nil)
    }
    
    static func alert(title: String, message : String, completion:@escaping () -> Void) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)//, blurStyle: .light)
        let OKAction = UIAlertAction(title: "OK", style: .default) {
            (action: UIAlertAction) in
            //print("You've pressed OK Button")
            completion()
        }
        alertController.addAction(OKAction)
        UIApplication.rootVC?.present(alertController, animated: true, completion: nil)
    }
    
    static func alert(title: String, message : String, actions:[String], style: [UIAlertAction.Style], completion:@escaping (_ index:Int) -> Void) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)//, blurStyle: .light)
        for i in 0..<actions.count {
            let act = UIAlertAction(title: actions[i], style: style[i], handler: { (actionn) in
                let index = actions.firstIndex(of: actionn.title!)
                completion(index!)
            })
            alertController.addAction(act)
        }
        UIApplication.rootVC?.present(alertController, animated: true, completion: nil)
    }
    
    static func alert(title: String, message : String, actions:[String], completion:@escaping (_ index:Int) -> Void) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)//, blurStyle: .light)
        for i in 0..<actions.count {
            let act = UIAlertAction(title: actions[i], style: .default, handler: { (actionn) in
                let indexx = actions.firstIndex(of: actionn.title!)
                completion(indexx!)
            })
            alertController.addAction(act)
        }
        UIApplication.rootVC?.present(alertController, animated: true, completion: nil)
    }
    
    static func alert(title: String, message : String, actions:[UIAlertAction]) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)//, blurStyle: .light)
        for action in actions {
            alertController.addAction(action)
        }
        UIApplication.rootVC?.present(alertController, animated: true, completion: nil)
    }
    
    static func alert(title: String, message : String, actions:[String], style: [UIAlertAction.Style], type: UIAlertController.Style, completion:@escaping (_ index:Int) -> Void) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: type)//, blurStyle: .light)
        for i in 0..<actions.count {
            let act = UIAlertAction(title: actions[i], style: style[i], handler: { (actionn) in
                let index = actions.firstIndex(of: actionn.title!)
                completion(index!)
            })
            alertController.addAction(act)
        }
        UIApplication.rootVC?.present(alertController, animated: true, completion: nil)
    }
    
}
extension UITextField{
    func setCurrentDate(formate:String = DateFormatter.appDateTimeFormat, date:Date = Date()) {
        self.text = date.dateAsString(formate: formate)
    }
}
struct StoryBoard {
    static let main = UIStoryboard(name: "Main", bundle: nil)
   
}

extension Date{
    func dateAsString(formate:String = DateFormatter.appDateTimeFormat) -> String{
        let formatter2 = DateFormatter()
        formatter2.dateFormat = formate
        let selectedDate = formatter2.string(from: self)
        return selectedDate
    }
}

extension UIViewController {
    
    static var identifier: String {
        return String(describing: self)
    }
    

    
    func present(asPopUpView vc: UIViewController, completion: (() -> Void)? = nil) {
        vc.modalPresentationStyle = .overCurrentContext
        vc.modalTransitionStyle = .crossDissolve
        self.present(vc, animated: true, completion: completion)
    }
    
}
