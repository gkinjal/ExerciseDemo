//
//  ViewController.swift
//  ExerciseDemo
//
//  Created by kinjal.gadhia.ext@bayer.com on 04/02/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var indicator: UIActivityIndicatorView!
    @IBOutlet weak var tblView: UITableView!{
        didSet{
            tblView.dataSource = self
            tblView.delegate = self
            tblView.tableFooterView = UIView()
            tblView.separatorStyle = .none
            tblView.showsHorizontalScrollIndicator = false
            tblView.showsVerticalScrollIndicator = false
        }
    }
    @IBOutlet weak var lblTitle: UILabel!
    var date = Date()
    var meetingData:[Meetings]?
    var dateFormatterGet = DateFormatter()
    var dateFormatPrint = DateFormatter()
    override func viewDidLoad() {
        super.viewDidLoad()
        dateFormatterGet.dateFormat = "dd/MM/yyyy"
        dateFormatPrint.dateFormat = "dd-MM-yyyy"
        lblTitle.text = dateFormatPrint.string(from: date)
        indicator.hidesWhenStopped = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if UserDefaults.standard.object(forKey: "element") != nil{
            let dic = UserDefaults.standard.object(forKey: "element") as! [String:Any]
            let meetElement = Meetings(dictionary: dic)
            self.meetingData = [meetElement]
            self.tblView.reloadData()
        }
        
    }
    
    @IBAction func onClickPrev(_ sender: UIButton) {
        date = date.getPreviousMonth()
        lblTitle.text = dateFormatPrint.string(from: date)
        getMeetings(date: dateFormatterGet.string(from: date))
    }
    
    @IBAction func onClickNext(_ sender: UIButton) {
        date = date.getNextMonth()
        lblTitle.text = dateFormatPrint.string(from: date)
        getMeetings(date: dateFormatterGet.string(from: date))
    }
    
    @IBAction func onClickSchedule(_ sender: UIButton) {
        let vc = ScheduleMeetingVC.storyboardInstance
        vc.meetingData = meetingData
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    
    
    func getMeetings(date:String) {
        indicator.startAnimating()
        let url = URL(string: "http://fathomless-shelf-5846.herokuapp.com/api/schedule?date=\(date)")!
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            
            
            guard error == nil else {
                return
            }
            
            guard let data = data else {
                return
            }
            
            
            do {
                let json = try JSONDecoder().decode([Meetings].self, from: data )
                self.meetingData = json
                
                DispatchQueue.main.async {
                    self.indicator.stopAnimating()
                    if UserDefaults.value(forKey: "element") != nil{
                        let meetElement = Meetings(dictionary: UserDefaults.value(forKey: "element") as! [String:Any])
                        self.meetingData?.append(meetElement)
                    }
                    self.tblView.reloadData()
                }
                
                print(json)
            } catch {
                print("Error during JSON serialization: \(error.localizedDescription)")
            }
            
        }
        task.resume()
        
    }
}

extension Date {
    func getNextMonth() -> Date {
        let date = Calendar.current.date(byAdding: .day, value: 1, to: self)!
        let calendar = Calendar(identifier: .gregorian)
        let components = calendar.dateComponents([.weekday], from: date)
        if components.weekday == 7 {
            return Calendar.current.date(byAdding: .day, value: 3, to: self)!
        }else if components.weekday == 1 {
            return Calendar.current.date(byAdding: .day, value: 2, to: self)!
        }
        else{
            return Calendar.current.date(byAdding: .day, value: 1, to: self)!
        }
    }
    
    func getPreviousMonth() -> Date {
        let date = Calendar.current.date(byAdding: .day, value: -1, to: self)!
        let calendar = Calendar(identifier: .gregorian)
        let components = calendar.dateComponents([.weekday], from: date)
        if components.weekday == 1 {
            return Calendar.current.date(byAdding: .day, value: -3, to: self)!
        }
        else{
            return Calendar.current.date(byAdding: .day, value: -1, to: self)!
        }
    }
}


extension ViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "MeetingCell")as? MeetingCell  else {
            fatalError("Cell can't be dequeue")
        }
        cell.lblDate.text = "\(meetingData?[indexPath.row].start_time ?? "") - \(meetingData?[indexPath.row].end_time ?? "")"
        cell.lblDesc.text = "\(meetingData?[indexPath.row].description ?? "")"
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return meetingData?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    
    
    
}
