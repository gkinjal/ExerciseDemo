//
//  DataModel.swift
//  ExerciseDemo
//
//  Created by kinjal.gadhia.ext@bayer.com on 04/02/22.
//

import Foundation


class Meetings : Decodable {
    var start_time : String
    var end_time : String
    var description : String
    
    
    init(dictionary: [String:Any]) {
        start_time = dictionary["start_time"] as? String ?? ""
        end_time = dictionary["end_time"] as? String ?? ""
        description = dictionary["description"] as? String ?? ""
        
    }
    
    func dictionaryRepresentation() -> [String:Any] {
           let dictionary = NSMutableDictionary()
           dictionary.setValue(self.start_time, forKey: "start_time")
        dictionary.setValue(self.end_time, forKey: "end_time")
        dictionary.setValue(self.description, forKey: "description")
        return dictionary as! [String:Any]
    }
    
}


